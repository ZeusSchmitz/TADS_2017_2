package finaljob;
import java.io.File;

public class Sequencial {
    File arq;
    public  Sequencial(File arq){
         
        
        
        
        
    }
    
}
