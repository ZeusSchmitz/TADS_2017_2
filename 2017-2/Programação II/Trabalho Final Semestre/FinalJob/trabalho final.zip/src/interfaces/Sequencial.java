package interfaces;

public interface Sequencial {
    
}
